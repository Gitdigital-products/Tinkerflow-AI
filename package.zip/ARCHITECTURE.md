# Architecture Overview

This document provides a comprehensive overview of the ZK-Solana KYC Compliance SDK architecture, design decisions, and implementation details.

## Table of Contents

1. [System Overview](#system-overview)
2. [High-Level Architecture](#high-level-architecture)
3. [Component Details](#component-details)
4. [Data Flow](#data-flow)
5. [Security Model](#security-model)
6. [Upgrade Path](#upgrade-path)

## System Overview

### Purpose

The ZK-Solana KYC Compliance SDK provides a privacy-preserving compliance framework for Solana token transfers. It leverages:

- **Solana Token Extensions (Token-2022)**: For advanced token functionality
- **Transfer Hooks**: For intercepting and validating transfers
- **Zero-Knowledge Proofs**: For privacy-preserving verification

### Core Features

1. **Identity Registry**: On-chain storage of verified identities (hashed)
2. **Transfer Validation**: Automatic compliance checks on transfers
3. **Tiered Compliance**: Multiple compliance levels with different requirements
4. **Geographic Restrictions**: Country-based transfer restrictions
5. **Time-Based Expiry**: Automatic expiration of verifications
6. **Privacy Preservation**: Hash-only storage of PII

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        APPLICATION LAYER                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐   │
│  │  Web App    │  │ Mobile App  │  │ Backend Service     │   │
│  └──────┬──────┘  └──────┬──────┘  └──────────┬──────────┘   │
│         │                 │                     │               │
│         └─────────────────┼─────────────────────┘               │
│                           │                                     │
│                    ┌──────▼──────┐                              │
│                    │  TypeScript │                              │
│                    │     SDK     │                              │
│                    └──────┬──────┘                              │
└───────────────────────────┼─────────────────────────────────────┘
                            │
┌───────────────────────────┼─────────────────────────────────────┐
│                    ┌──────▼──────┐    SOLANA CLUSTER           │
│                    │  RPC Node   │                              │
│                    └──────┬──────┘                              │
│                           │                                     │
│         ┌─────────────────┼─────────────────────┐              │
│         │                 │                     │              │
│   ┌─────▼─────┐    ┌──────▼──────┐    ┌───────┴────────┐      │
│   │  Token    │    │    KYC      │    │   Identity     │      │
│   │ Program   │───▶│  Compliance │◀───│   Accounts     │      │
│   │ (2022)    │    │   Program   │    │   (PDAs)       │      │
│   └───────────┘    └─────────────┘    └────────────────┘      │
│                           │                                     │
│                    ┌──────▼──────┐                              │
│                    │  Registry   │                              │
│                    │   Account   │                              │
│                    └─────────────┘                              │
└─────────────────────────────────────────────────────────────────┘
```

## Component Details

### 1. On-Chain Program (Rust/Anchor)

#### Registry Account

The central configuration account storing global compliance settings.

```rust
#[account]
pub struct Registry {
    pub authority: Pubkey,           // Admin key
    pub delegate: Option<Pubkey>,    // Operational key
    pub is_paused: bool,             // Global pause
    pub required_compliance_level: u8, // Min level
    pub max_transfer_amount: u64,    // Transfer limit
    pub require_both_verified: bool,  // Both parties verified
    pub allow_self_transfer: bool,    // Self-transfer bypass
    pub restricted_countries: Vec<[u8; 2]>, // Blocked countries
    pub bump: u8,
}
```

#### Identity Account

User-specific account storing verification status.

```rust
#[account]
pub struct Identity {
    pub owner: Pubkey,
    pub registry: Pubkey,
    pub compliance_hash: [u8; 32],  // ZK proof root
    pub expiry: i64,                // Expiration time
    pub compliance_level: u8,       // Tier (1-10)
    pub country_code: [u8; 2],      // ISO country
    pub is_frozen: bool,            // Transfer blocked
    pub is_revoked: bool,           // Permanently removed
    pub is_kyc_verified: bool,      // KYC passed
    pub is_aml_verified: bool,      // AML passed
    pub bump: u8,
}
```

#### Transfer Hook

Implements the SPL Transfer Hook interface for automatic validation.

```rust
// Called automatically on every transfer
pub fn execute_transfer_hook(ctx: Context<ExecuteTransferHook>, amount: u64) -> ProgramResult {
    // 1. Check registry is not paused
    // 2. Validate source identity
    // 3. Validate destination identity
    // 4. Check transfer amount limits
    // 5. Allow or reject the transfer
}
```

### 2. TypeScript SDK

The client library for interacting with the program.

```typescript
class KycClient {
  // Registry management
  async initializeRegistry(authority: PublicKey, args: InitializeRegistryArgs): Promise<string>
  async updateRegistry(authority: PublicKey, args: UpdateRegistryArgs): Promise<string>

  // Identity management
  async registerIdentity(authority: PublicKey, args: RegisterIdentityArgs): Promise<string>
  async updateIdentity(authority: PublicKey, owner: PublicKey, args: UpdateIdentityArgs): Promise<string>
  async freezeIdentity(authority: PublicKey, owner: PublicKey): Promise<string>
  async unfreezeIdentity(authority: PublicKey, owner: PublicKey): Promise<string>

  // Queries
  async getRegistry(): Promise<RegistryData | null>
  async getIdentity(owner: PublicKey): Promise<IdentityData | null>
  async isVerified(owner: PublicKey): Promise<boolean>
  async validateTransfer(source: PublicKey, dest: PublicKey, amount: number): Promise<{allowed: boolean, reason?: string}>
}
```

### 3. PDA Derivation

All on-chain accounts use Program-Derived Addresses (PDAs) for secure, deterministic addressing.

```
Registry PDA:
  seeds = [b"registry"]
  program = KYC_COMPLIANCE_PROGRAM_ID

Identity PDA:
  seeds = [b"identity", registry, owner]
  program = KYC_COMPLIANCE_PROGRAM_ID

Mint Compliance PDA:
  seeds = [b"mint_metadata", mint]
  program = KYC_COMPLIANCE_PROGRAM_ID
```

## Data Flow

### Registration Flow

```
1. User submits KYC data to off-chain service
       │
       ▼
2. Off-chain service verifies identity (KYC/AML)
       │
       ▼
3. Service computes compliance hash
       │
       ▼
4. Service calls register_identity instruction via SDK
       │
       ▼
5. Program creates Identity PDA with hash + metadata
       │
       ▼
6. User can now receive/send compliant tokens
```

### Transfer Flow

```
1. User A initiates token transfer to User B
       │
       ▼
2. Token Program invokes Transfer Hook
       │
       ▼
3. Hook derives Identity PDAs for A and B
       │
       ▼
4. Hook validates both identities:
   - Not expired
   - Not frozen
   - Not revoked
   - KYC verified
   - Compliance level sufficient
   - Country not restricted
       │
       ▼
5. If valid: Transfer completes
   If invalid: Transfer fails with error
```

## Security Model

### Authority Model

- **Registry Authority**: Full control over registry settings
- **Delegate**: Limited operational control (no registry changes)
- **Users**: Can only interact with their own identity accounts

### Access Control

| Operation | Authority | Delegate | User |
|------------|-----------|----------|------|
| Initialize Registry | ✓ | ✗ | ✗ |
| Update Registry | ✓ | ✗ | ✗ |
| Pause Registry | ✓ | ✗ | ✗ |
| Register Identity | ✓ | ✓ | ✗ |
| Update Identity | ✓ | ✓ | ✗ |
| Freeze Identity | ✓ | ✓ | ✗ |
| Revoke Identity | ✓ | ✗ | ✗ |
| Transfer Tokens | ✓ | ✓ | ✓ |

### Security Considerations

1. **PDA Validation**: All account derivations are validated
2. **Signature Verification**: All mutations require authorization
3. **Overflow Protection**: Math operations use checked arithmetic
4. **Data Validation**: All inputs are validated before use
5. **Privacy**: Only hashes stored on-chain, not PII

## Upgrade Path

### Version Compatibility

| Component | Version | Notes |
|-----------|---------|-------|
| Anchor | 0.30.x | Required |
| Solana | 1.18.x | Required |
| Token-2022 | 4.0.x | Required |
| SPL Transfer Hook | 0.5.x | Required |

### Migration Strategy

1. **Maintain backwards compatibility** within major versions
2. **Use feature flags** for new functionality
3. **Provide migration instructions** for breaking changes
4. **Support multi-version** during transition periods

### Future Enhancements

1. **ZK Proof Integration**: Full zero-knowledge proof support
2. **Multi-Sig Support**: Multi-signature for high-value operations
3. **Rate Limiting**: Configurable transfer velocity limits
4. **Audit Logging**: Comprehensive event emission
5. **Partial Transfers**: Allowlist for specific amounts

## Testing Strategy

### Unit Tests

- Core logic validation
- PDA derivation verification
- Error case handling

### Integration Tests

- Full workflow execution
- Multiple user scenarios
- Edge cases

### Validator Tests

- Local cluster testing
- Full program deployment
- End-to-end flows

---

For more details, see the [README](README.md) and [CONTRIBUTING](CONTRIBUTING.md) guides.
