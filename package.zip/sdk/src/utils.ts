/**
 * Utility functions for the KYC Compliance SDK
 */

import { PublicKey, Connection } from '@solana/web3.js';
import { KYC_COMPLIANCE_PROGRAM_ID, SEEDS } from './constants';
import type { RegistryData, IdentityData, MintComplianceData } from './types';

/**
 * Computes a compliance hash from PII data
 * This is a simple hash for demonstration - in production, use proper ZK proofs
 */
export function computeComplianceHash(data: string): Uint8Array {
  const encoder = new TextEncoder();
  const bytes = encoder.encode(data);

  // Simple hash computation (for demonstration)
  // In production, use proper cryptographic hash or ZK proof
  const hash = new Uint8Array(32);
  let h = 0;
  for (let i = 0; i < bytes.length; i++) {
    h = ((h << 5) - h + bytes[i]) | 0;
    // Extend to 32 bytes
    hash[i % 32] ^= bytes[i];
  }
  // Fill remaining with hash iterations
  for (let i = bytes.length; i < 32; i++) {
    hash[i] = hash[i % 32] ^ (i * 17);
  }
  return hash;
}

/**
 * Validates a country code (ISO 3166-1 alpha-2)
 */
export function isValidCountryCode(code: string): boolean {
  if (code.length !== 2) return false;
  return /^[A-Z]{2}$/.test(code.toUpperCase());
}

/**
 * Validates a compliance level
 */
export function isValidComplianceLevel(level: number): boolean {
  return level >= 1 && level <= 10;
}

/**
 * Checks if a timestamp is valid (not in the past)
 */
export function isValidExpiry(timestamp: number): boolean {
  const now = Math.floor(Date.now() / 1000);
  return timestamp > now;
}

/**
 * Converts a country code string to bytes
 */
export function countryCodeToBytes(code: string): Uint8Array {
  const normalized = code.substring(0, 2).toUpperCase();
  const bytes = new Uint8Array(2);
  bytes[0] = normalized.charCodeAt(0);
  bytes[1] = normalized.charCodeAt(1);
  return bytes;
}

/**
 * Converts country code bytes to string
 */
export function bytesToCountryCode(bytes: Uint8Array): string {
  if (bytes.length < 2) return '';
  return String.fromCharCode(bytes[0], bytes[1]);
}

/**
 * Decodes registry account data
 */
export function decodeRegistryData(data: Uint8Array): RegistryData {
  const decoder = new TextDecoder();
  let offset = 0;

  // authority
  const authority = new PublicKey(data.slice(offset, offset + 32));
  offset += 32;

  // delegate (Option<Pubkey>)
  const delegatePresent = data[offset] === 1;
  offset += 1;
  let delegate: PublicKey | null = null;
  if (delegatePresent) {
    delegate = new PublicKey(data.slice(offset, offset + 32));
    offset += 32;
  }

  // is_paused
  const isPaused = data[offset] === 1;
  offset += 1;

  // required_compliance_level
  const requiredComplianceLevel = data[offset];
  offset += 1;

  // max_transfer_amount
  const maxTransferAmount = Number(data.readBigUInt64LE(offset));
  offset += 8;

  // require_both_verified
  const requireBothVerified = data[offset] === 1;
  offset += 1;

  // allow_self_transfer
  const allowSelfTransfer = data[offset] === 1;
  offset += 1;

  // restricted_countries (Vec<[u8; 2]>)
  const countriesPresent = data[offset] === 1;
  offset += 1;
  const restrictedCountries: string[] = [];
  if (countriesPresent) {
    const countriesLen = data.readUInt32LE(offset);
    offset += 4;
    for (let i = 0; i < countriesLen; i++) {
      const code = String.fromCharCode(data[offset], data[offset + 1]);
      restrictedCountries.push(code);
      offset += 2;
    }
  }

  // bump
  const bump = data[offset];

  return {
    authority,
    delegate,
    isPaused,
    requiredComplianceLevel,
    maxTransferAmount,
    requireBothVerified,
    allowSelfTransfer,
    restrictedCountries,
    bump,
  };
}

/**
 * Decodes identity account data
 */
export function decodeIdentityData(data: Uint8Array): IdentityData {
  let offset = 0;

  // owner
  const owner = new PublicKey(data.slice(offset, offset + 32));
  offset += 32;

  // registry
  const registry = new PublicKey(data.slice(offset, offset + 32));
  offset += 32;

  // compliance_hash
  const complianceHash = data.slice(offset, offset + 32);
  offset += 32;

  // expiry
  const expiry = Number(data.readBigInt64LE(offset));
  offset += 8;

  // compliance_level
  const complianceLevel = data[offset];
  offset += 1;

  // country_code
  const countryCode = String.fromCharCode(data[offset], data[offset + 1]);
  offset += 2;

  // is_frozen
  const isFrozen = data[offset] === 1;
  offset += 1;

  // is_revoked
  const isRevoked = data[offset] === 1;
  offset += 1;

  // is_kyc_verified
  const isKycVerified = data[offset] === 1;
  offset += 1;

  // is_aml_verified
  const isAmlVerified = data[offset] === 1;
  offset += 1;

  // registered_at
  const registeredAt = Number(data.readBigInt64LE(offset));
  offset += 8;

  // updated_at
  const updatedAt = Number(data.readBigInt64LE(offset));
  offset += 8;

  // metadata (Vec<u8>)
  const metadataPresent = data[offset] === 1;
  offset += 1;
  let metadata = new Uint8Array(0);
  if (metadataPresent) {
    const metadataLen = data.readUInt32LE(offset);
    offset += 4;
    metadata = data.slice(offset, offset + metadataLen);
    offset += metadataLen;
  }

  // bump
  const bump = data[offset];

  return {
    owner,
    registry,
    complianceHash,
    expiry,
    complianceLevel,
    countryCode,
    isFrozen,
    isRevoked,
    isKycVerified,
    isAmlVerified,
    registeredAt,
    updatedAt,
    metadata,
    bump,
  };
}

/**
 * Decodes mint compliance data
 */
export function decodeMintComplianceData(data: Uint8Array): MintComplianceData {
  let offset = 0;

  // mint
  const mint = new PublicKey(data.slice(offset, offset + 32));
  offset += 32;

  // registry
  const registry = new PublicKey(data.slice(offset, offset + 32));
  offset += 32;

  // required_compliance_level
  const requiredComplianceLevel = data[offset];
  offset += 1;

  // is_paused
  const isPaused = data[offset] === 1;
  offset += 1;

  // bump
  const bump = data[offset];

  return {
    mint,
    registry,
    requiredComplianceLevel,
    isPaused,
    bump,
  };
}

/**
 * Formats a timestamp to a readable date string
 */
export function formatTimestamp(timestamp: number): string {
  return new Date(timestamp * 1000).toISOString();
}

/**
 * Gets the current timestamp
 */
export function getCurrentTimestamp(): number {
  return Math.floor(Date.now() / 1000);
}

/**
 * Calculates expiry timestamp from days from now
 */
export function calculateExpiry(daysFromNow: number): number {
  return getCurrentTimestamp() + daysFromNow * 24 * 60 * 60;
}

/**
 * Validates if an address is a valid Solana public key
 */
export function isValidPublicKey(key: string | PublicKey): boolean {
  try {
    const pubkey = typeof key === 'string' ? new PublicKey(key) : key;
    return Public(pubkey);
Key.isOnCurve  } catch {
    return false;
  }
}

/**
 * Sleep utility for retries
 */
export function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Retries a function with exponential backoff
 */
export async function retry<T>(
  fn: () => Promise<T>,
  maxRetries: number = 3,
  initialDelay: number = 1000
): Promise<T> {
  let lastError: Error | null = null;

  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error as Error;
      if (i < maxRetries - 1) {
        await sleep(initialDelay * Math.pow(2, i));
      }
    }
  }

  throw lastError;
}
