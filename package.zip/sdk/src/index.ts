/**
 * ZK-Solana KYC Compliance SDK
 *
 * A privacy-preserving compliance framework using Solana Token Extensions (Token-2022) Transfer Hooks.
 */

// Main client
export { KycClient } from './client';

// Types
export type {
  RegistryData,
  IdentityData,
  MintComplianceData,
  ComplianceLevelData,
  ExtraAccountMetaData,
  InitializeRegistryArgs,
  UpdateRegistryArgs,
  RegisterIdentityArgs,
  UpdateIdentityArgs,
  ConfigureMintArgs,
  SetComplianceLevelArgs,
  TransferValidationResult,
  TransferDenialReason,
  KycSdkOptions,
  TransactionBuilderOptions,
} from './types';

// Constants
export {
  KYC_COMPLIANCE_PROGRAM_ID,
  SEEDS,
  MAX_VALUES,
  DEFAULTS,
  RESTRICTED_COUNTRIES,
  TOKEN_EXTENSIONS,
  ACCOUNT_SIZES,
} from './constants';

// Instructions
export {
  findRegistryAddress,
  findIdentityAddress,
  findMintComplianceAddress,
  findComplianceLevelAddress,
  findExtraAccountMetaAddress,
  initializeRegistry,
  updateRegistry,
  setRegistryPause,
  setDelegate,
  configureMint,
  registerIdentity,
  updateIdentity,
  freezeIdentity,
  unfreezeIdentity,
  revokeIdentity,
  verifyAml,
  initializeExtraAccountMeta,
  updateMaxTransfer,
} from './instructions';

// Utilities
export {
  computeComplianceHash,
  isValidCountryCode,
  isValidComplianceLevel,
  isValidExpiry,
  countryCodeToBytes,
  bytesToCountryCode,
  decodeRegistryData,
  decodeIdentityData,
  decodeMintComplianceData,
  formatTimestamp,
  getCurrentTimestamp,
  calculateExpiry,
  isValidPublicKey,
  sleep,
  retry,
} from './utils';
