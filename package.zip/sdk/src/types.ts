/**
 * Type definitions for the KYC Compliance SDK
 */

import { PublicKey } from '@solana/web3.js';

/**
 * Registry configuration data
 */
export interface RegistryData {
  /** The authority that manages the registry */
  authority: PublicKey;
  /** Optional delegate that can perform certain operations */
  delegate: PublicKey | null;
  /** Whether transfers are currently paused */
  isPaused: boolean;
  /** Minimum compliance level required */
  requiredComplianceLevel: number;
  /** Maximum transfer amount per transaction */
  maxTransferAmount: number;
  /** Whether both sender and receiver must be verified */
  requireBothVerified: boolean;
  /** Whether self-transfers bypass verification */
  allowSelfTransfer: boolean;
  /** List of restricted country codes */
  restrictedCountries: string[];
  /** Bump seed for PDA */
  bump: number;
}

/**
 * Identity account data
 */
export interface IdentityData {
  /** Owner of the identity */
  owner: PublicKey;
  /** Registry this identity belongs to */
  registry: PublicKey;
  /** Compliance hash (privacy-preserving) */
  complianceHash: Uint8Array;
  /** Expiration timestamp */
  expiry: number;
  /** Compliance level achieved (1-10) */
  complianceLevel: number;
  /** Country code (ISO 3166-1 alpha-2) */
  countryCode: string;
  /** Whether identity is frozen */
  isFrozen: boolean;
  /** Whether identity is revoked */
  isRevoked: boolean;
  /** Whether KYC has been verified */
  isKycVerified: boolean;
  /** Whether AML has been verified */
  isAmlVerified: boolean;
  /** Registration timestamp */
  registeredAt: number;
  /** Last update timestamp */
  updatedAt: number;
  /** Additional metadata */
  metadata: Uint8Array;
  /** Bump seed for PDA */
  bump: number;
}

/**
 * Mint compliance configuration
 */
export interface MintComplianceData {
  /** The mint address */
  mint: PublicKey;
  /** Associated registry */
  registry: PublicKey;
  /** Required compliance level for this mint */
  requiredComplianceLevel: number;
  /** Whether transfers are paused for this mint */
  isPaused: boolean;
  /** Bump seed */
  bump: number;
}

/**
 * Compliance level definition
 */
export interface ComplianceLevelData {
  /** Level number (1-10) */
  level: number;
  /** Human-readable name */
  name: string;
  /** Description of requirements */
  description: string;
  /** Whether KYC is required */
  requiresKyc: boolean;
  /** Whether AML verification is required */
  requiresAml: boolean;
  /** Whether proof of residency is required */
  requiresResidency: boolean;
  /** Maximum transfer limit (0 = unlimited) */
  maxTransferLimit: number;
  /** Bump seed */
  bump: number;
}

/**
 * Extra account meta for transfer hook
 */
export interface ExtraAccountMetaData {
  /** Mint address */
  mint: PublicKey;
  /** Associated registry */
  registry: PublicKey;
  /** Whether hook is active */
  isActive: boolean;
  /** Bump seed */
  bump: number;
}

/**
 * Initialize registry instruction arguments
 */
export interface InitializeRegistryArgs {
  /** Minimum compliance level required */
  requiredComplianceLevel: number;
  /** Whether both sender and receiver must be verified */
  requireBothVerified: boolean;
  /** Whether self-transfers bypass verification */
  allowSelfTransfer: boolean;
  /** List of restricted country codes */
  restrictedCountries: string[];
}

/**
 * Update registry instruction arguments
 */
export interface UpdateRegistryArgs {
  /** New minimum compliance level (optional) */
  requiredComplianceLevel?: number;
  /** New require both verified setting (optional) */
  requireBothVerified?: boolean;
  /** New allow self transfer setting (optional) */
  allowSelfTransfer?: boolean;
  /** New restricted countries (optional) */
  restrictedCountries?: string[];
}

/**
 * Register identity instruction arguments
 */
export interface RegisterIdentityArgs {
  /** Owner to register */
  owner: PublicKey;
  /** Compliance hash */
  complianceHash: Uint8Array;
  /** Expiration timestamp */
  expiry: number;
  /** Compliance level achieved */
  complianceLevel: number;
  /** Country code */
  countryCode: string;
}

/**
 * Update identity instruction arguments
 */
export interface UpdateIdentityArgs {
  /** New expiry (optional) */
  expiry?: number;
  /** New compliance level (optional) */
  complianceLevel?: number;
  /** New country code (optional) */
  countryCode?: string;
  /** New metadata (optional) */
  metadata?: Uint8Array;
}

/**
 * Configure mint instruction arguments
 */
export interface ConfigureMintArgs {
  /** Mint to configure */
  mint: PublicKey;
  /** Required compliance level */
  requiredComplianceLevel: number;
}

/**
 * Set compliance level instruction arguments
 */
export interface SetComplianceLevelArgs {
  /** Level number (1-10) */
  level: number;
  /** Human-readable name */
  name: string;
  /** Description */
  description: string;
  /** Whether KYC is required */
  requiresKyc: boolean;
  /** Whether AML is required */
  requiresAml: boolean;
  /** Whether residency is required */
  requiresResidency: boolean;
  /** Maximum transfer limit */
  maxTransferLimit: number;
}

/**
 * Transfer validation result
 */
export interface TransferValidationResult {
  /** Source wallet */
  source: PublicKey;
  /** Destination wallet */
  destination: PublicKey;
  /** Whether transfer is allowed */
  allowed: boolean;
  /** Reason if denied */
  denialReason?: TransferDenialReason;
  /** Timestamp */
  timestamp: number;
}

/**
 * Reasons for transfer denial
 */
export enum TransferDenialReason {
  SourceNotFound = 'SOURCE_NOT_FOUND',
  DestinationNotFound = 'DESTINATION_NOT_FOUND',
  SourceExpired = 'SOURCE_EXPIRED',
  DestinationExpired = 'DESTINATION_EXPIRED',
  SourceFrozen = 'SOURCE_FROZEN',
  DestinationFrozen = 'DESTINATION_FROZEN',
  SourceRevoked = 'SOURCE_REVOKED',
  DestinationRevoked = 'DESTINATION_REVOKED',
  SourceComplianceLevelTooLow = 'SOURCE_COMPLIANCE_LEVEL_TOO_LOW',
  DestinationComplianceLevelTooLow = 'DESTINATION_COMPLIANCE_LEVEL_TOO_LOW',
  SourceCountryRestricted = 'SOURCE_COUNTRY_RESTRICTED',
  DestinationCountryRestricted = 'DESTINATION_COUNTRY_RESTRICTED',
  AmountExceedsLimit = 'AMOUNT_EXCEEDS_LIMIT',
  RegistryPaused = 'REGISTRY_PAUSED',
}

/**
 * SDK configuration options
 */
export interface KycSdkOptions {
  /** Program ID (defaults to mainnet) */
  programId?: PublicKey;
  /** Commitment level for queries */
  commitment?: 'processed' | 'confirmed' | 'finalized';
}

/**
 * Transaction builder options
 */
export interface TransactionBuilderOptions {
  /** Additional signers */
  signers?: any[];
  /** Whether to skipPreflight */
  skipPreflight?: boolean;
  /** Max retries */
  maxRetries?: number;
}
