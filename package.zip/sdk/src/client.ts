/**
 * Main client for interacting with the KYC Compliance program
 */

import {
  Connection,
  PublicKey,
  Transaction,
  TransactionSignature,
  SendTransactionOptions,
} from '@solana/web3.js';
import {
  getAssociatedTokenAddress,
  getTokenAccountBalance,
  getMint,
  transfer,
  TOKEN_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
} from '@solana/spl-token';
import {
  KYC_COMPLIANCE_PROGRAM_ID,
  DEFAULTS,
  MAX_VALUES,
} from './constants';
import type {
  RegistryData,
  IdentityData,
  MintComplianceData,
  InitializeRegistryArgs,
  UpdateRegistryArgs,
  RegisterIdentityArgs,
  UpdateIdentityArgs,
  ConfigureMintArgs,
  KycSdkOptions,
} from './types';
import {
  findRegistryAddress,
  findIdentityAddress,
  findMintComplianceAddress,
  findExtraAccountMetaAddress,
  initializeRegistry,
  updateRegistry,
  setRegistryPause,
  setDelegate,
  configureMint,
  registerIdentity,
  updateIdentity,
  freezeIdentity,
  unfreezeIdentity,
  revokeIdentity,
  verifyAml,
  initializeExtraAccountMeta,
  updateMaxTransfer,
} from './instructions';
import {
  decodeRegistryData,
  decodeIdentityData,
  decodeMintComplianceData,
  computeComplianceHash,
  isValidCountryCode,
  isValidComplianceLevel,
  isValidExpiry,
} from './utils';

/**
 * Main SDK client for KYC Compliance
 */
export class KycClient {
  /** Connection to the Solana cluster */
  public readonly connection: Connection;

  /** Program ID */
  public readonly programId: PublicKey;

  /** Registry PDA */
  public readonly registryAddress: PublicKey;

  /**
   * Creates a new KYC client
   */
  constructor(connection: Connection, options?: KycSdkOptions) {
    this.connection = connection;
    this.programId = options?.programId ?? KYC_COMPLIANCE_PROGRAM_ID;
    this.registryAddress = findRegistryAddress();
  }

  /**
   * Initializes a new registry
   */
  async initializeRegistry(
    authority: PublicKey,
    args: InitializeRegistryArgs,
    options?: SendTransactionOptions
  ): Promise<TransactionSignature> {
    // Validate inputs
    if (!isValidComplianceLevel(args.requiredComplianceLevel)) {
      throw new Error('Invalid compliance level');

      if (args.restrictedCountries.some(c => !isValidCountryCode(c))) {
        throw new Error('Invalid country code');
      }
    }

    const instruction = await initializeRegistry(args, authority);
    const transaction = new Transaction().add(instruction);

    return this.connection.sendTransaction(transaction, [authority], options);
  }

  /**
   * Updates the registry configuration
   */
  async updateRegistry(
    authority: PublicKey,
    args: UpdateRegistryArgs,
    options?: SendTransactionOptions
  ): Promise<TransactionSignature> {
    if (args.requiredComplianceLevel !== undefined && !isValidComplianceLevel(args.requiredComplianceLevel)) {
      throw new Error('Invalid compliance level');
    }

    if (args.restrictedCountries?.some(c => !isValidCountryCode(c))) {
      throw new Error('Invalid country code');
    }

    const instruction = await updateRegistry(args, authority);
    const transaction = new Transaction().add(instruction);

    return this.connection.sendTransaction(transaction, [authority], options);
  }

  /**
   * Pauses or unpauses the registry
   */
  async setRegistryPause(
    authority: PublicKey,
    paused: boolean,
    options?: SendTransactionOptions
  ): Promise<TransactionSignature> {
    const instruction = await setRegistryPause(paused, authority);
    const transaction = new Transaction().add(instruction);

    return this.connection.sendTransaction(transaction, [authority], options);
  }

  /**
   * Sets the delegate for the registry
   */
  async setDelegate(
    authority: PublicKey,
    delegate: PublicKey | null,
    options?: SendTransactionOptions
  ): Promise<TransactionSignature> {
    const instruction = await setDelegate(delegate, authority);
    const transaction = new Transaction().add(instruction);

    return this.connection.sendTransaction(transaction, [authority], options);
  }

  /**
   * Configures a mint for compliance
   */
  async configureMint(
    authority: PublicKey,
    args: ConfigureMintArgs,
    options?: SendTransactionOptions
  ): Promise<TransactionSignature> {
    if (!isValidComplianceLevel(args.requiredComplianceLevel)) {
      throw new Error('Invalid compliance level');
    }

    const instruction = await configureMint(args, authority);
    const transaction = new Transaction().add(instruction);

    return this.connection.sendTransaction(transaction, [authority], options);
  }

  /**
   * Registers a new identity
   */
  async registerIdentity(
    authority: PublicKey,
    args: RegisterIdentityArgs,
    options?: SendTransactionOptions
  ): Promise<TransactionSignature> {
    // Validate inputs
    if (!isValidCountryCode(args.countryCode)) {
      throw new Error('Invalid country code');
    }

    if (!isValidComplianceLevel(args.complianceLevel)) {
      throw new Error('Invalid compliance level');
    }

    if (!isValidExpiry(args.expiry)) {
      throw new Error('Invalid expiry timestamp');
    }

    if (args.complianceHash.length !== MAX_VALUES.COMPLIANCE_HASH_LENGTH) {
      throw new Error('Invalid compliance hash length');
    }

    const instruction = await registerIdentity(args, authority);
    const transaction = new Transaction().add(instruction);

    return this.connection.sendTransaction(transaction, [authority], options);
  }

  /**
   * Updates an existing identity
   */
  async updateIdentity(
    authority: PublicKey,
    owner: PublicKey,
    args: UpdateIdentityArgs,
    options?: SendTransactionOptions
  ): Promise<TransactionSignature> {
    if (args.expiry !== undefined && !isValidExpiry(args.expiry)) {
      throw new Error('Invalid expiry timestamp');
    }

    if (args.complianceLevel !== undefined && !isValidComplianceLevel(args.complianceLevel)) {
      throw new Error('Invalid compliance level');
    }

    if (args.countryCode !== undefined && !isValidCountryCode(args.countryCode)) {
      throw new Error('Invalid country code');
    }

    const instruction = await updateIdentity(owner, args, authority);
    const transaction = new Transaction().add(instruction);

    return this.connection.sendTransaction(transaction, [authority], options);
  }

  /**
   * Freezes an identity
   */
  async freezeIdentity(
    authority: PublicKey,
    owner: PublicKey,
    options?: SendTransactionOptions
  ): Promise<TransactionSignature> {
    const instruction = await freezeIdentity(owner, authority);
    const transaction = new Transaction().add(instruction);

    return this.connection.sendTransaction(transaction, [authority], options);
  }

  /**
   * Unfreezes an identity
   */
  async unfreezeIdentity(
    authority: PublicKey,
    owner: PublicKey,
    options?: SendTransactionOptions
  ): Promise<TransactionSignature> {
    const instruction = await unfreezeIdentity(owner, authority);
    const transaction = new Transaction().add(instruction);

    return this.connection.sendTransaction(transaction, [authority], options);
  }

  /**
   * Revokes an identity
   */
  async revokeIdentity(
    authority: PublicKey,
    owner: PublicKey,
    options?: SendTransactionOptions
  ): Promise<TransactionSignature> {
    const instruction = await revokeIdentity(owner, authority);
    const transaction = new Transaction().add(instruction);

    return this.connection.sendTransaction(transaction, [authority], options);
  }

  /**
   * Verifies AML for an identity
   */
  async verifyAml(
    authority: PublicKey,
    owner: PublicKey,
    options?: SendTransactionOptions
  ): Promise<TransactionSignature> {
    const instruction = await verifyAml(owner, authority);
    const transaction = new Transaction().add(instruction);

    return this.connection.sendTransaction(transaction, [authority], options);
  }

  /**
   * Initializes extra account meta for a mint
   */
  async initializeExtraAccountMeta(
    authority: PublicKey,
    mint: PublicKey,
    options?: SendTransactionOptions
  ): Promise<TransactionSignature> {
    const instruction = await initializeExtraAccountMeta(mint, authority);
    const transaction = new Transaction().add(instruction);

    return this.connection.sendTransaction(transaction, [authority], options);
  }

  /**
   * Updates max transfer amount
   */
  async updateMaxTransfer(
    authority: PublicKey,
    maxAmount: number,
    options?: SendTransactionOptions
  ): Promise<TransactionSignature> {
    const instruction = await updateMaxTransfer(maxAmount, authority);
    const transaction = new Transaction().add(instruction);

    return this.connection.sendTransaction(transaction, [authority], options);
  }

  // ==================== Query Methods ====================

  /**
   * Fetches the registry data
   */
  async getRegistry(): Promise<RegistryData | null> {
    try {
      const accountInfo = await this.connection.getAccountInfo(this.registryAddress);
      if (!accountInfo) return null;

      return decodeRegistryData(new Uint8Array(accountInfo.data));
    } catch (error) {
      console.error('Error fetching registry:', error);
      return null;
    }
  }

  /**
   * Fetches an identity by owner
   */
  async getIdentity(owner: PublicKey): Promise<IdentityData | null> {
    try {
      const identityAddress = findIdentityAddress(this.registryAddress, owner);
      const accountInfo = await this.connection.getAccountInfo(identityAddress);

      if (!accountInfo) return null;

      return decodeIdentityData(new Uint8Array(accountInfo.data));
    } catch (error) {
      console.error('Error fetching identity:', error);
      return null;
    }
  }

  /**
   * Fetches multiple identities
   */
  async getIdentities(owners: PublicKey[]): Promise<Map<string, IdentityData | null>> {
    const results = new Map<string, IdentityData | null>();

    await Promise.all(
      owners.map(async (owner) => {
        const identity = await this.getIdentity(owner);
        results.set(owner.toString(), identity);
      })
    );

    return results;
  }

  /**
   * Fetches mint compliance data
   */
  async getMintCompliance(mint: PublicKey): Promise<MintComplianceData | null> {
    try {
      const address = findMintComplianceAddress(mint);
      const accountInfo = await this.connection.getAccountInfo(address);

      if (!accountInfo) return null;

      return decodeMintComplianceData(new Uint8Array(accountInfo.data));
    } catch (error) {
      console.error('Error fetching mint compliance:', error);
      return null;
    }
  }

  /**
   * Checks if an address is verified
   */
  async isVerified(owner: PublicKey): Promise<boolean> {
    const identity = await this.getIdentity(owner);
    if (!identity) return false;

    return (
      identity.isKycVerified &&
      !identity.isFrozen &&
      !identity.isRevoked &&
      identity.expiry > Math.floor(Date.now() / 1000)
    );
  }

  /**
   * Validates a transfer (off-chain simulation)
   */
  async validateTransfer(
    source: PublicKey,
    destination: PublicKey,
    amount: number
  ): Promise<{ allowed: boolean; reason?: string }> {
    const registry = await this.getRegistry();

    if (!registry) {
      return { allowed: false, reason: 'Registry not initialized' };
    }

    if (registry.isPaused) {
      return { allowed: false, reason: 'Registry is paused' };
    }

    // Self-transfer check
    if (source.equals(destination) && registry.allowSelfTransfer) {
      return { allowed: true };
    }

    // Get identities
    const sourceIdentity = await this.getIdentity(source);
    const destIdentity = await this.getIdentity(destination);

    // Check source
    if (sourceIdentity) {
      if (sourceIdentity.isFrozen) {
        return { allowed: false, reason: 'Source is frozen' };
      }
      if (sourceIdentity.isRevoked) {
        return { allowed: false, reason: 'Source is revoked' };
      }
      if (sourceIdentity.expiry < Math.floor(Date.now() / 1000)) {
        return { allowed: false, reason: 'Source identity expired' };
      }
      if (sourceIdentity.complianceLevel < registry.requiredComplianceLevel) {
        return { allowed: false, reason: 'Source compliance level too low' };
      }
    } else if (registry.requireBothVerified) {
      return { allowed: false, reason: 'Source not verified' };
    }

    // Check destination
    if (destIdentity) {
      if (destIdentity.isFrozen) {
        return { allowed: false, reason: 'Destination is frozen' };
      }
      if (destIdentity.isRevoked) {
        return { allowed: false, reason: 'Destination is revoked' };
      }
      if (destIdentity.expiry < Math.floor(Date.now() / 1000)) {
        return { allowed: false, reason: 'Destination identity expired' };
      }
      if (destIdentity.complianceLevel < registry.requiredComplianceLevel) {
        return { allowed: false, reason: 'Destination compliance level too low' };
      }
    } else if (registry.requireBothVerified) {
      return { allowed: false, reason: 'Destination not verified' };
    }

    // Check amount
    if (amount > registry.maxTransferAmount) {
      return { allowed: false, reason: 'Amount exceeds limit' };
    }

    return { allowed: true };
  }

  /**
   * Gets all required accounts for a transfer hook
   */
  async getTransferHookAccounts(mint: PublicKey) {
    const registry = await this.getRegistry();
    const mintCompliance = await this.getMintCompliance(mint);

    return {
      registry: this.registryAddress,
      mint,
      extraAccountMeta: findExtraAccountMetaAddress(mint),
    };
  }
}

export { KycClient as default };
