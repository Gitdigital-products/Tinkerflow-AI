//! Registry account state
//!
//! Defines the global configuration for the KYC compliance system.

use crate::constants::{DEFAULT_COMPLIANCE_LEVEL, MAX_COMPLIANCE_LEVELS};
use anchor_lang::prelude::*;

/// Registry configuration account
///
/// This account holds the global compliance settings and authority information.
/// There should only be one registry per deployment or per token mint group.
#[account]
#[derive(Debug, InitSpace)]
pub struct Registry {
    /// The authority that can manage the registry (typically the admin)
    pub authority: Pubkey,

    /// Optional delegate that can perform certain operations
    /// (e.g., an oracle or automated compliance service)
    pub delegate: Option<Pubkey>,

    /// Whether transfers are currently paused
    pub is_paused: bool,

    /// Minimum compliance level required for transfers
    pub required_compliance_level: u8,

    /// Maximum transfer amount per transaction (in token units)
    pub max_transfer_amount: u64,

    /// Whether to require both sender and receiver to be verified
    pub require_both_verified: bool,

    /// Whether to allow self-transfers without verification
    pub allow_self_transfer: bool,

    /// Optional list of restricted country codes (ISO 3166-1 alpha-2)
    pub restricted_countries: Vec<[u8; 2]>,

    /// Bump seed for PDA derivation
    pub bump: u8,

    /// Reserved space for future upgrades
    #[max_len(256)]
    pub reserved: Vec<u8>,
}

impl Registry {
    /// Creates a new registry with default settings
    pub fn new(authority: Pubkey, bump: u8) -> Self {
        Self {
            authority,
            delegate: None,
            is_paused: false,
            required_compliance_level: DEFAULT_COMPLIANCE_LEVEL,
            max_transfer_amount: u64::MAX,
            require_both_verified: true,
            allow_self_transfer: false,
            restricted_countries: Vec::new(),
            bump,
            reserved: Vec::new(),
        }
    }

    /// Returns whether the registry is active (not paused)
    pub fn is_active(&self) -> bool {
        !self.is_paused
    }

    /// Validates the compliance level
    pub fn is_valid_compliance_level(&self, level: u8) -> bool {
        level > 0 && level <= MAX_COMPLIANCE_LEVELS
    }

    /// Checks if a country code is restricted
    pub fn is_country_restricted(&self, country_code: &[u8; 2]) -> bool {
        self.restricted_countries
            .iter()
            .any(|c| c == country_code)
    }

    /// Validates that the compliance level meets requirements
    pub fn meets_requirement(&self, level: u8) -> bool {
        level >= self.required_compliance_level
    }
}

/// Mint-specific compliance configuration
///
/// Associates a mint with a specific registry and compliance requirements.
#[account]
#[derive(Debug, InitSpace)]
pub struct MintCompliance {
    /// The mint address this configuration applies to
    pub mint: Pubkey,

    /// The registry this mint is associated with
    pub registry: Pubkey,

    /// Minimum compliance level for this specific mint
    pub required_compliance_level: u8,

    /// Whether transfers are paused for this mint
    pub is_paused: bool,

    /// Bump seed for PDA derivation
    pub bump: u8,

    /// Reserved space for future upgrades
    #[max_len(128)]
    pub reserved: Vec<u8>,
}

impl MintCompliance {
    /// Creates a new mint compliance configuration
    pub fn new(mint: Pubkey, registry: Pubkey, required_compliance_level: u8, bump: u8) -> Self {
        Self {
            mint,
            registry,
            required_compliance_level,
            is_paused: false,
            bump,
            reserved: Vec::new(),
        }
    }

    /// Returns whether transfers are allowed for this mint
    pub fn transfers_allowed(&self) -> bool {
        !self.is_paused
    }
}

/// Compliance level definition
///
/// Defines the requirements for each compliance tier.
#[account]
#[derive(Debug, InitSpace)]
pub struct ComplianceLevel {
    /// The level number (1-10)
    pub level: u8,

    /// Human-readable name for this level
    #[max_len(32)]
    pub name: String,

    /// Description of requirements for this level
    #[max_len(256)]
    pub description: String,

    /// Whether KYC is required at this level
    pub requires_kyc: bool,

    /// Whether AML verification is required at this level
    pub requires_aml: bool,

    /// Whether proof of residency is required at this level
    pub requires_residency: bool,

    /// Maximum transfer limit at this level (0 = unlimited)
    pub max_transfer_limit: u64,

    /// Bump seed for PDA derivation
    pub bump: u8,

    /// Reserved space for future upgrades
    #[max_len(128)]
    pub reserved: Vec<u8>,
}

impl ComplianceLevel {
    /// Creates a new compliance level definition
    pub fn new(
        level: u8,
        name: String,
        description: String,
        requires_kyc: bool,
        requires_aml: bool,
        requires_residency: bool,
        max_transfer_limit: u64,
        bump: u8,
    ) -> Self {
        Self {
            level,
            name,
            description,
            requires_kyc,
            requires_aml,
            requires_residency,
            max_transfer_limit,
            bump,
            reserved: Vec::new(),
        }
    }
}
