//! Identity account state
//!
//! Defines the user identity and compliance verification state.

use crate::constants::{COMPLIANCE_HASH_LENGTH, COUNTRY_CODE_LENGTH};
use anchor_lang::prelude::*;
use anchor_lang::solana_program::clock::Clock;

/// Identity account for a verified user
///
/// Stores the compliance verification status and metadata for a single user.
#[account]
#[derive(Debug, InitSpace)]
pub struct Identity {
    /// The owner of this identity account
    pub owner: Pubkey,

    /// The registry this identity belongs to
    pub registry: Pubkey,

    /// Compliance hash (SHA-256 or ZK proof root)
    /// This preserves privacy by only storing a hash of the PII
    pub compliance_hash: [u8; COMPLIANCE_HASH_LENGTH],

    /// Timestamp when this identity expires
    /// After this time, the identity is no longer valid
    pub expiry: i64,

    /// Compliance level achieved (1-10)
    pub compliance_level: u8,

    /// Country code (ISO 3166-1 alpha-2)
    pub country_code: [u8; COUNTRY_CODE_LENGTH],

    /// Whether this identity is frozen (cannot transfer)
    pub is_frozen: bool,

    /// Whether this identity has been revoked
    pub is_revoked: bool,

    /// Whether KYC has been verified
    pub is_kyc_verified: bool,

    /// Whether AML screening has been passed
    pub is_aml_verified: bool,

    /// Timestamp when the identity was registered
    pub registered_at: i64,

    /// Timestamp of the last update
    pub updated_at: i64,

    /// Additional metadata (JSON string or URI)
    #[max_len(512)]
    pub metadata: Vec<u8>,

    /// Bump seed for PDA derivation
    pub bump: u8,

    /// Reserved space for future upgrades
    #[max_len(256)]
    pub reserved: Vec<u8>,
}

impl Identity {
    /// Creates a new identity account
    pub fn new(
        owner: Pubkey,
        registry: Pubkey,
        compliance_hash: [u8; COMPLIANCE_HASH_LENGTH],
        expiry: i64,
        compliance_level: u8,
        country_code: [u8; COUNTRY_CODE_LENGTH],
        bump: u8,
    ) -> Self {
        let clock = Clock::get().unwrap_or_else(|_| Clock::default());
        let now = clock.unix_timestamp;

        Self {
            owner,
            registry,
            compliance_hash,
            expiry,
            compliance_level,
            country_code,
            is_frozen: false,
            is_revoked: false,
            is_kyc_verified: false,
            is_aml_verified: false,
            registered_at: now,
            updated_at: now,
            metadata: Vec::new(),
            bump,
            reserved: Vec::new(),
        }
    }

    /// Returns whether the identity is currently valid for transfers
    pub fn is_active(&self) -> bool {
        let clock = Clock::get().unwrap_or_else(|_| Clock::default());
        let now = clock.unix_timestamp;

        !self.is_frozen
            && !self.is_revoked
            && now < self.expiry
            && self.is_kyc_verified
    }

    /// Returns whether the identity has expired
    pub fn is_expired(&self) -> bool {
        let clock = Clock::get().unwrap_or_else(|_| Clock::default());
        let now = clock.unix_timestamp;

        now >= self.expiry
    }

    /// Returns whether the identity meets the required compliance level
    pub fn meets_requirement(&self, required_level: u8) -> bool {
        self.compliance_level >= required_level
    }

    /// Returns whether the identity is from a restricted country
    pub fn is_from_restricted_country(&self, restricted: &[[u8; 2]]) -> bool {
        restricted.iter().any(|c| c == &self.country_code)
    }

    /// Updates the identity expiry
    pub fn update_expiry(&mut self, new_expiry: i64) {
        let clock = Clock::get().unwrap_or_else(|_| Clock::default());
        self.expiry = new_expiry;
        self.updated_at = clock.unix_timestamp;
    }

    /// Freezes the identity
    pub fn freeze(&mut self) {
        let clock = Clock::get().unwrap_or_else(|_| Clock::default());
        self.is_frozen = true;
        self.updated_at = clock.unix_timestamp;
    }

    /// Unfreezes the identity
    pub fn unfreeze(&mut self) {
        let clock = Clock::get().unwrap_or_else(|_| Clock::default());
        self.is_frozen = false;
        self.updated_at = clock.unix_timestamp;
    }

    /// Revokes the identity
    pub fn revoke(&mut self) {
        let clock = Clock::get().unwrap_or_else(|_| Clock::default());
        self.is_revoked = true;
        self.is_frozen = true;
        self.updated_at = clock.unix_timestamp;
    }

    /// Updates the compliance level
    pub fn update_compliance_level(&mut self, level: u8) {
        let clock = Clock::get().unwrap_or_else(|_| Clock::default());
        self.compliance_level = level;
        self.updated_at = clock.unix_timestamp;
    }

    /// Marks KYC as verified
    pub fn verify_kyc(&mut self) {
        let clock = Clock::get().unwrap_or_else(|_| Clock::default());
        self.is_kyc_verified = true;
        self.updated_at = clock.unix_timestamp;
    }

    /// Marks AML as verified
    pub fn verify_aml(&mut self) {
        let clock = Clock::get().unwrap_or_else(|_| Clock::default());
        self.is_aml_verified = true;
        self.updated_at = clock.unix_timestamp;
    }
}

/// Identity verification event
///
/// Emitted when a new identity is registered or updated.
#[event]
pub struct IdentityRegistered {
    /// The owner of the identity
    pub owner: Pubkey,

    /// The registry this identity belongs to
    pub registry: Pubkey,

    /// The compliance level achieved
    pub compliance_level: u8,

    /// Timestamp of registration
    pub timestamp: i64,
}

/// Identity update event
///
/// Emitted when an identity is updated.
#[event]
pub struct IdentityUpdated {
    /// The owner of the identity
    pub owner: Pubkey,

    /// The registry this identity belongs to
    pub registry: Pubkey,

    /// Type of update
    pub update_type: IdentityUpdateType,

    /// Timestamp of update
    pub timestamp: i64,
}

/// Types of identity updates
#[derive(Debug, Clone, AnchorSerialize, AnchorDeserialize)]
pub enum IdentityUpdateType {
    /// Identity was frozen
    Frozen,
    /// Identity was unfrozen
    Unfrozen,
    /// Identity was revoked
    Revoked,
    /// Compliance level updated
    ComplianceLevelUpdated,
    /// Expiry updated
    ExpiryUpdated,
    /// KYC verified
    KycVerified,
    /// AML verified
    AmlVerified,
}

/// Transfer validation result
///
/// Emitted after a transfer is validated.
#[event]
pub struct TransferValidationResult {
    /// Source owner
    pub source: Pubkey,

    /// Destination owner
    pub destination: Pubkey,

    /// Whether the transfer was allowed
    pub allowed: bool,

    /// Reason if denied
    pub denial_reason: Option<TransferDenialReason>,

    /// Timestamp
    pub timestamp: i64,
}

/// Reasons for transfer denial
#[derive(Debug, Clone, AnchorSerialize, AnchorDeserialize)]
pub enum TransferDenialReason {
    /// Source identity not found
    SourceNotFound,
    /// Destination identity not found
    DestinationNotFound,
    /// Source identity expired
    SourceExpired,
    /// Destination identity expired
    DestinationExpired,
    /// Source identity frozen
    SourceFrozen,
    /// Destination identity frozen
    DestinationFrozen,
    /// Source identity revoked
    SourceRevoked,
    /// Destination identity revoked
    DestinationRevoked,
    /// Source compliance level too low
    SourceComplianceLevelTooLow,
    /// Destination compliance level too low
    DestinationComplianceLevelTooLow,
    /// Source country restricted
    SourceCountryRestricted,
    /// Destination country restricted
    DestinationCountryRestricted,
    /// Transfer amount exceeds limit
    AmountExceedsLimit,
    /// Registry paused
    RegistryPaused,
}
