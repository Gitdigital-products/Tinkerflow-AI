//! State module for the KYC Compliance program
//!
//! Contains all state account definitions used by the program.

pub mod identity;
pub mod registry;

pub use identity::*;
pub use registry::*;
