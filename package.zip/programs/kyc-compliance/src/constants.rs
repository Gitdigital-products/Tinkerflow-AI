//! Constants for the KYC Compliance program
//!
//! Defines all constant values used throughout the program.

/// Maximum length for a country code (ISO 3166-1 alpha-2)
pub const COUNTRY_CODE_LENGTH: usize = 2;

/// Maximum length for a compliance hash (SHA-256)
pub const COMPLIANCE_HASH_LENGTH: usize = 32;

/// Maximum length for metadata URI
pub const METADATA_URI_LENGTH: usize = 200;

/// Maximum number of compliance levels
pub const MAX_COMPLIANCE_LEVELS: u8 = 10;

/// Default compliance level required for transfers
pub const DEFAULT_COMPLIANCE_LEVEL: u8 = 1;

/// Maximum expiry timestamp (year 2100)
pub const MAX_EXPIRY: i64 = 4102444800;

/// Minimum expiry timestamp (now)
pub const MIN_EXPIRY: i64 = 1;

/// Maximum transfer amount per transaction (default: 1 billion tokens)
pub const DEFAULT_MAX_TRANSFER_AMOUNT: u64 = 1_000_000_000;

/// Bump seed for registry PDA
pub const REGISTRY_BUMP: u8 = 255;

/// Bump seed for identity PDA
pub const IDENTITY_BUMP: u8 = 254;

/// Seed version for PDA derivation
pub const SEED_VERSION: u8 = 1;

/// Supported token extensions
pub mod token_extensions {
    /// Transfer Hook enabled
    pub const TRANSFER_HOOK: u64 = 1 << 0;

    /// Permanent Delegate enabled
    pub const PERMANENT_DELEGATE: u64 = 1 << 1;

    /// Metadata Pointer enabled
    pub const METADATA_POINTER: u64 = 1 << 2;

    /// Default: All extensions supported
    pub const ALL: u64 = TRANSFER_HOOK | PERMANENT_DELEGATE | METADATA_POINTER;
}

/// Restricted countries (ISO 3166-1 alpha-2 codes)
pub mod restricted_countries {
    pub const CU: &[u8; 2] = b"CU"; // Cuba
    pub const IR: &[u8; 2] = b"IR"; // Iran
    pub const KP: &[u8; 2] = b"KP"; // North Korea
    pub const SY: &[u8; 2] = b"SY"; // Syria
    pub const RU: &[u8; 2] = b"RU"; // Russia (partial)
    pub const BY: &[u8; 2] = b"BY"; // Belarus

    /// All restricted country codes
    pub const ALL: &[&[u8; 2]] = &[CU, IR, KP, SY, RU, BY];
}

/// Program-owned accounts seeds
pub mod pda_seeds {
    /// Registry seed
    pub const REGISTRY: &[u8] = b"registry";

    /// Identity seed
    pub const IDENTITY: &[u8] = b"identity";

    /// Mint metadata seed
    pub const MINT_METADATA: &[u8] = b"mint_metadata";

    /// Compliance level seed
    pub const COMPLIANCE_LEVEL: &[u8] = b"compliance_level";

    /// Extra account meta seed
    pub const EXTRA_ACCOUNT_META: &[u8] = b"extra_account_meta";
}
