//! Instructions module for the KYC Compliance program
//!
//! Contains all instruction handlers for the program.

pub mod admin;
pub mod hook;
pub mod identity;

pub use admin::*;
pub use hook::*;
pub use identity::*;
