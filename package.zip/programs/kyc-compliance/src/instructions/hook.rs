//! Transfer Hook implementation
//!
//! Implements the SPL Transfer Hook interface for compliance verification.

use crate::constants::pda_seeds;
use crate::errors::KycError;
use crate::state::{Identity, MintCompliance, Registry, TransferDenialReason, TransferValidationResult};
use anchor_lang::prelude::*;
use anchor_lang::solana_program::clock::Clock;
use anchor_lang::solana_program::instruction::AccountMeta;
use anchor_lang::solana_program::program::set_return_data;
use anchor_lang::solana_program::{entrypoint::ProgramResult, program::invoke_signed};
use anchor_spl::token::TransferHook;
use spl_transfer_hook_interface::instruction::{ExecuteInstruction, TransferHookInstruction};

/// Extra account metadata for the transfer hook
///
/// This account holds the registry and mint compliance associations
/// needed for the transfer hook execution.
#[account]
#[derive(Debug, InitSpace)]
pub struct ExtraAccountMeta {
    /// The mint this extra data applies to
    pub mint: Pubkey,

    /// The registry this mint uses
    pub registry: Pubkey,

    /// Whether this hook is active
    pub is_active: bool,

    /// Bump seed
    pub bump: u8,

    /// Reserved space
    #[max_len(128)]
    pub reserved: Vec<u8>,
}

impl ExtraAccountMeta {
    /// Creates new extra account meta
    pub fn new(mint: Pubkey, registry: Pubkey, bump: u8) -> Self {
        Self {
            mint,
            registry,
            is_active: true,
            bump,
            reserved: Vec::new(),
        }
    }
}

/// Extra account meta for a mint
#[derive(Accounts)]
#[instruction(mint: Pubkey)]
pub struct InitializeExtraAccountMeta<'info> {
    /// The authority (registry admin) signing the transaction
    #[account(mut)]
    pub authority: Signer<'info>,

    /// The system program
    pub system_program: Program<'info, System>,

    /// The registry account
    #[account(
        seeds = [pda_seeds::REGISTRY],
        bump = registry.bump
    )]
    pub registry: Account<'info, Registry>,

    /// The mint account
    pub mint: Account<'info, anchor_spl::token::Mint>,

    /// The extra account meta to create
    #[account(
        init,
        seeds = [pda_seeds::EXTRA_ACCOUNT_META, &mint.key().to_bytes()],
        bump,
        payer = authority,
        space = ExtraAccountMeta::INIT_SPACE
    )]
    pub extra_account_meta: Account<'info, ExtraAccountMeta>,
}

impl<'info> InitializeExtraAccountMeta<'info> {
    pub fn handler(ctx: Context<Self>, mint: Pubkey) -> Result<()> {
        let registry = &ctx.accounts.registry;

        // Validate authority
        if registry.authority != ctx.accounts.authority.key() {
            return Err(KycError::InvalidAuthority.into());
        }

        let extra_account_meta = &mut ctx.accounts.extra_account_meta;
        let bump = ctx.bumps.extra_account_meta;

        extra_account_meta.mint = mint;
        extra_account_meta.registry = registry.key();
        extra_account_meta.is_active = true;
        extra_account_meta.bump = bump;
        extra_account_meta.reserved = Vec::new();

        msg!("Extra account meta initialized for mint: {}", mint);
        Ok(())
    }
}

/// The transfer hook execute instruction
///
/// This is called by the SPL Token Program when a transfer occurs.
#[derive(Accounts)]
pub struct ExecuteTransferHook<'info> {
    /// The KYC Compliance program
    pub kyc_program: Program<'info, KycCompliance>,

    /// The registry account
    #[account(
        seeds = [pda_seeds::REGISTRY],
        bump = registry.bump
    )]
    pub registry: Account<'info, Registry>,

    /// Source token account
    pub from: AccountInfo<'info>,

    /// Destination token account
    pub to: AccountInfo<'info>,

    /// The mint
    pub mint: AccountInfo<'info>,

    /// Source owner (signer for the transfer)
    pub authority: Signer<'info>,
}

impl<'info> ExecuteTransferHook<'info> {
    /// Validates a transfer according to KYC requirements
    pub fn handler(ctx: Context<Self>, amount: u64) -> ProgramResult {
        let registry = &ctx.accounts.registry;

        // Check if registry is paused
        if registry.is_paused {
            Self::emit_denial(
                ctx.accounts.authority.key(),
                Pubkey::default(),
                TransferDenialReason::RegistryPaused,
            )?;
            return Err(KycError::RegistryPaused.into());
        }

        // Get source and destination owners
        let source_owner = ctx.accounts.authority.key();
        let destination_owner = Self::get_token_account_owner(&ctx.accounts.to)?;

        // Allow self-transfer if configured
        if source_owner == destination_owner && registry.allow_self_transfer {
            Self::emit_approval(source_owner, destination_owner)?;
            return Ok(());
        }

        // Get or derive identity accounts
        let source_identity = Self::get_identity(ctx, &registry.key(), &source_owner)?;
        let dest_identity = Self::get_identity(ctx, &registry.key(), &destination_owner)?;

        // Check source identity
        if let Some(identity) = source_identity {
            Self::validate_identity(
                identity,
                registry,
                TransferDenialReason::SourceNotFound,
                TransferDenialReason::SourceExpired,
                TransferDenialReason::SourceFrozen,
                TransferDenialReason::SourceRevoked,
                TransferDenialReason::SourceComplianceLevelTooLow,
                TransferDenialReason::SourceCountryRestricted,
            )?;
        } else if registry.require_both_verified {
            Self::emit_denial(
                source_owner,
                destination_owner,
                TransferDenialReason::SourceNotFound,
            )?;
            return Err(KycError::SourceIdentityNotFound.into());
        }

        // Check destination identity
        if let Some(identity) = dest_identity {
            Self::validate_identity(
                identity,
                registry,
                TransferDenialReason::DestinationNotFound,
                TransferDenialReason::DestinationExpired,
                TransferDenialReason::DestinationFrozen,
                TransferDenialReason::DestinationRevoked,
                TransferDenialReason::DestinationComplianceLevelTooLow,
                TransferDenialReason::DestinationCountryRestricted,
            )?;
        } else if registry.require_both_verified {
            Self::emit_denial(
                source_owner,
                destination_owner,
                TransferDenialReason::DestinationNotFound,
            )?;
            return Err(KycError::DestinationIdentityNotFound.into());
        }

        // Check transfer amount limit
        if amount > registry.max_transfer_amount {
            Self::emit_denial(
                source_owner,
                destination_owner,
                TransferDenialReason::AmountExceedsLimit,
            )?;
            return Err(KycError::TransferAmountExceedsLimit.into());
        }

        // Transfer allowed
        Self::emit_approval(source_owner, destination_owner)?;

        msg!(
            "Transfer validated: {} -> {} ({} tokens)",
            source_owner,
            destination_owner,
            amount
        );

        Ok(())
    }

    /// Gets the identity account for a user
    fn get_identity(
        ctx: &Context<ExecuteTransferHook>,
        registry_key: &Pubkey,
        owner: &Pubkey,
    ) -> Result<Option<Identity>> {
        let (identity_key, _) = Pubkey::find_program_address(
            &[pda_seeds::IDENTITY, &registry_key.to_bytes(), &owner.to_bytes()],
            &crate::KYC_COMPLIANCE_PROGRAM_ID,
        );

        let account_info_iter = &mut ctx.remaining_accounts.iter();
        while let Some(account_info) = account_info_iter.next() {
            if account_info.key == &identity_key {
                if account_info.data_is_empty() {
                    return Ok(None);
                }
                return Ok(Some(Identity::try_from_slice(&account_info.data.borrow())?));
            }
        }

        Ok(None)
    }

    /// Gets the owner of a token account
    fn get_token_account_owner(token_account: &AccountInfo) -> Result<Pubkey> {
        // Parse token account data to get owner
        // This is a simplified version - in production, use proper token account parsing
        let data = token_account.data.borrow();
        let owner_offset = 32; // Owner is at offset 32 in token account
        if data.len() < owner_offset + 32 {
            return Err(KycError::InvalidAccountData.into());
        }
        let owner_bytes: [u8; 32] = data[owner_offset..owner_offset + 32]
            .try_into()
            .map_err(|_| KycError::InvalidAccountData.into())?;
        Ok(Pubkey::new_from_array(owner_bytes))
    }

    /// Validates an identity for transfer
    fn validate_identity(
        identity: &Identity,
        registry: &Registry,
        not_found_reason: TransferDenialReason,
        expired_reason: TransferDenialReason,
        frozen_reason: TransferDenialReason,
        revoked_reason: TransferDenialReason,
        level_reason: TransferDenialReason,
        country_reason: TransferDenialReason,
    ) -> Result<()> {
        // Check if identity exists (should be caught by Option handling)

        // Check expiry
        if identity.is_expired() {
            Self::emit_denial(identity.owner, Pubkey::default(), expired_reason)?;
            return Err(KycError::IdentityExpired.into());
        }

        // Check frozen
        if identity.is_frozen {
            Self::emit_denial(identity.owner, Pubkey::default(), frozen_reason)?;
            return Err(KycError::IdentityFrozen.into());
        }

        // Check revoked
        if identity.is_revoked {
            Self::emit_denial(identity.owner, Pubkey::default(), revoked_reason)?;
            return Err(KycError::IdentityVerificationFailed.into());
        }

        // Check KYC verification
        if !identity.is_kyc_verified {
            Self::emit_denial(identity.owner, Pubkey::default(), not_found_reason)?;
            return Err(KycError::SourceNotVerified.into());
        }

        // Check compliance level
        if !identity.meets_requirement(registry.required_compliance_level) {
            Self::emit_denial(identity.owner, Pubkey::default(), level_reason)?;
            return Err(KycError::ComplianceLevelTooLow.into());
        }

        // Check country restrictions
        if registry.is_country_restricted(&identity.country_code) {
            Self::emit_denial(identity.owner, Pubkey::default(), country_reason)?;
            return Err(KycError::CountryNotAllowed.into());
        }

        Ok(())
    }

    /// Emits a transfer denial event
    fn emit_denial(source: Pubkey, destination: Pubkey, reason: TransferDenialReason) -> Result<()> {
        emit!(TransferValidationResult {
            source,
            destination,
            allowed: false,
            denial_reason: Some(reason),
            timestamp: Clock::get()?.unix_timestamp,
        });
        Ok(())
    }

    /// Emits a transfer approval event
    fn emit_approval(source: Pubkey, destination: Pubkey) -> Result<()> {
        emit!(TransferValidationResult {
            source,
            destination,
            allowed: true,
            denial_reason: None,
            timestamp: Clock::get()?.unix_timestamp,
        });
        Ok(())
    }
}

/// CPI handler for transfer hook
/// Used when the KYC program is called from another program via CPI
#[derive(Accounts)]
pub struct CpiExecuteTransferHook<'info> {
    /// The KYC Compliance program
    pub kyc_program: Program<'info, KycCompliance>,

    /// The registry account
    #[account(
        seeds = [pda_seeds::REGISTRY],
        bump = registry.bump
    )]
    pub registry: Account<'info, Registry>,

    /// Source token account
    pub from: AccountInfo<'info>,

    /// Destination token account
    pub to: AccountInfo<'info>,

    /// The mint
    pub mint: AccountInfo<'info>,

    /// Authority (can be derived from signature or PDA)
    pub authority: AccountInfo<'info>,
}

impl<'info> CpiExecuteTransferHook<'info> {
    /// Executes the transfer hook via CPI
    pub fn handler(ctx: Context<Self>, amount: u64) -> ProgramResult {
        // This is called via CPI, so we use the same validation logic
        ExecuteTransferHook::handler(ctx, amount)
    }
}
