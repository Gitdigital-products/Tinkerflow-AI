//! Admin instructions for the KYC Compliance program
//!
//! Contains instructions for managing the registry and global settings.

use crate::constants::{pda_seeds, MAX_COMPLIANCE_LEVELS};
use crate::errors::KycError;
use crate::state::{ComplianceLevel, MintCompliance, Registry};
use anchor_lang::prelude::*;
use anchor_lang::solana_program::system_program;

/// Initializes a new registry
///
/// # Arguments
/// * `authority` - The admin authority for the registry
/// * `required_compliance_level` - Minimum compliance level for transfers
/// * `require_both_verified` - Whether both sender and receiver must be verified
/// * `allow_self_transfer` - Whether to allow transfers to self without verification
#[derive(Accounts)]
#[instruction(
    required_compliance_level: u8,
    require_both_verified: bool,
    allow_self_transfer: bool,
    restricted_countries: Vec<[u8; 2]>
)]
pub struct InitializeRegistry<'info> {
    /// The payer for the account creation
    #[account(mut)]
    pub payer: Signer<'info>,

    /// The system program
    #[account(address = system_program::ID)]
    pub system_program: Program<'info, System>,

    /// The registry account to initialize (PDA)
    #[account(
        init,
        seeds = [pda_seeds::REGISTRY],
        bump,
        payer = payer,
        space = Registry::INIT_SPACE
    )]
    pub registry: Account<'info, Registry>,
}

impl<'info> InitializeRegistry<'info> {
    pub fn handler(
        ctx: Context<Self>,
        required_compliance_level: u8,
        require_both_verified: bool,
        allow_self_transfer: bool,
        restricted_countries: Vec<[u8; 2]>,
    ) -> Result<()> {
        // Validate compliance level
        if required_compliance_level == 0 || required_compliance_level > MAX_COMPLIANCE_LEVELS {
            return Err(KycError::InvalidComplianceLevel.into());
        }

        let registry = &mut ctx.accounts.registry;
        let authority = ctx.accounts.payer.key();
        let bump = ctx.bumps.registry;

        registry.authority = authority;
        registry.delegate = None;
        registry.is_paused = false;
        registry.required_compliance_level = required_compliance_level;
        registry.max_transfer_amount = u64::MAX;
        registry.require_both_verified = require_both_verified;
        registry.allow_self_transfer = allow_self_transfer;
        registry.restricted_countries = restricted_countries;
        registry.bump = bump;
        registry.reserved = Vec::new();

        msg!("Registry initialized with authority: {}", authority);
        Ok(())
    }
}

/// Updates the registry settings
///
/// Only the authority can update the registry.
#[derive(Accounts)]
#[instruction(
    required_compliance_level: Option<u8>,
    require_both_verified: Option<bool>,
    allow_self_transfer: Option<bool>,
    restricted_countries: Option<Vec<[u8; 2]>>
)]
pub struct UpdateRegistry<'info> {
    /// The authority signing the transaction
    #[account(mut)]
    pub authority: Signer<'info>,

    /// The registry account to update
    #[account(
        mut,
        seeds = [pda_seeds::REGISTRY],
        bump = registry.bump
    )]
    pub registry: Account<'info, Registry>,
}

impl<'info> UpdateRegistry<'info> {
    pub fn handler(
        ctx: Context<Self>,
        required_compliance_level: Option<u8>,
        require_both_verified: Option<bool>,
        allow_self_transfer: Option<bool>,
        restricted_countries: Option<Vec<[u8; 2]>>,
    ) -> Result<()> {
        let registry = &mut ctx.accounts.registry;

        // Validate authority
        if registry.authority != ctx.accounts.authority.key() {
            return Err(KycError::InvalidAuthority.into());
        }

        // Update fields if provided
        if let Some(level) = required_compliance_level {
            if level > MAX_COMPLIANCE_LEVELS {
                return Err(KycError::InvalidComplianceLevel.into());
            }
            registry.required_compliance_level = level;
        }

        if let Some(value) = require_both_verified {
            registry.require_both_verified = value;
        }

        if let Some(value) = allow_self_transfer {
            registry.allow_self_transfer = value;
        }

        if let Some(countries) = restricted_countries {
            registry.restricted_countries = countries;
        }

        msg!("Registry updated successfully");
        Ok(())
    }
}

/// Pauses or unpauses the registry
///
/// When paused, all transfers are blocked.
#[derive(Accounts)]
pub struct SetRegistryPause<'info> {
    /// The authority signing the transaction
    #[account(mut)]
    pub authority: Signer<'info>,

    /// The registry account to update
    #[account(
        mut,
        seeds = [pda_seeds::REGISTRY],
        bump = registry.bump
    )]
    pub registry: Account<'info, Registry>,
}

impl<'info> SetRegistryPause<'info> {
    pub fn handler(ctx: Context<Self>, paused: bool) -> Result<()> {
        let registry = &mut ctx.accounts.registry;

        // Validate authority
        if registry.authority != ctx.accounts.authority.key() {
            return Err(KycError::InvalidAuthority.into());
        }

        registry.is_paused = paused;

        msg!(
            "Registry {}",
            if paused { "paused" } else { "unpaused" }
        );
        Ok(())
    }
}

/// Sets the delegate for the registry
///
/// The delegate can perform certain operations but cannot change core settings.
#[derive(Accounts)]
pub struct SetDelegate<'info> {
    /// The authority signing the transaction
    #[account(mut)]
    pub authority: Signer<'info>,

    /// The registry account to update
    #[account(
        mut,
        seeds = [pda_seeds::REGISTRY],
        bump = registry.bump
    )]
    pub registry: Account<'info, Registry>,
}

impl<'info> SetDelegate<'info> {
    pub fn handler(ctx: Context<Self>, delegate: Option<Pubkey>) -> Result<()> {
        let registry = &mut ctx.accounts.registry;

        // Validate authority
        if registry.authority != ctx.accounts.authority.key() {
            return Err(KycError::InvalidAuthority.into());
        }

        registry.delegate = delegate;

        msg!("Delegate updated successfully");
        Ok(())
    }
}

/// Configures a mint for compliance
///
/// Associates a Token-2022 mint with this registry.
#[derive(Accounts)]
#[instruction(required_compliance_level: u8)]
pub struct ConfigureMint<'info> {
    /// The authority signing the transaction
    #[account(mut)]
    pub authority: Signer<'info>,

    /// The system program
    #[account(address = system_program::ID)]
    pub system_program: Program<'info, System>,

    /// The registry account
    #[account(
        seeds = [pda_seeds::REGISTRY],
        bump = registry.bump
    )]
    pub registry: Account<'info, Registry>,

    /// The mint compliance configuration account
    #[account(
        init,
        seeds = [pda_seeds::MINT_METADATA, &mint.key().to_bytes()],
        bump,
        payer = authority,
        space = MintCompliance::INIT_SPACE
    )]
    pub mint_compliance: Account<'info, MintCompliance>,

    /// The mint to configure
    pub mint: Account<'info, anchor_spl::token::Mint>,
}

impl<'info> ConfigureMint<'info> {
    pub fn handler(
        ctx: Context<Self>,
        required_compliance_level: u8,
    ) -> Result<()> {
        let registry = &ctx.accounts.registry;

        // Validate authority
        if registry.authority != ctx.accounts.authority.key() {
            return Err(KycError::InvalidAuthority.into());
        }

        // Validate compliance level
        if required_compliance_level > MAX_COMPLIANCE_LEVELS {
            return Err(KycError::InvalidComplianceLevel.into());
        }

        let mint_compliance = &mut ctx.accounts.mint_compliance;
        let mint_key = ctx.accounts.mint.key();
        let bump = ctx.bumps.mint_compliance;

        mint_compliance.mint = mint_key;
        mint_compliance.registry = registry.key();
        mint_compliance.required_compliance_level = required_compliance_level;
        mint_compliance.is_paused = false;
        mint_compliance.bump = bump;
        mint_compliance.reserved = Vec::new();

        msg!("Mint {} configured for compliance", mint_key);
        Ok(())
    }
}

/// Updates the max transfer amount
#[derive(Accounts)]
pub struct UpdateMaxTransfer<'info> {
    /// The authority signing the transaction
    #[account(mut)]
    pub authority: Signer<'info>,

    /// The registry account to update
    #[account(
        mut,
        seeds = [pda_seeds::REGISTRY],
        bump = registry.bump
    )]
    pub registry: Account<'info, Registry>,
}

impl<'info> UpdateMaxTransfer<'info> {
    pub fn handler(ctx: Context<Self>, max_amount: u64) -> Result<()> {
        let registry = &mut ctx.accounts.registry;

        // Validate authority
        if registry.authority != ctx.accounts.authority.key() {
            return Err(KycError::InvalidAuthority.into());
        }

        registry.max_transfer_amount = max_amount;

        msg!("Max transfer amount updated to: {}", max_amount);
        Ok(())
    }
}

/// Creates or updates a compliance level definition
#[derive(Accounts)]
#[instruction(level: u8, name: String, description: String, requires_kyc: bool, requires_aml: bool, requires_residency: bool, max_transfer_limit: u64)]
pub struct SetComplianceLevel<'info> {
    /// The authority signing the transaction
    #[account(mut)]
    pub authority: Signer<'info>,

    /// The registry account
    #[account(
        seeds = [pda_seeds::REGISTRY],
        bump = registry.bump
    )]
    pub registry: Account<'info, Registry>,

    /// The compliance level account
    #[account(
        init_if_needed,
        seeds = [pda_seeds::COMPLIANCE_LEVEL, &[level]],
        bump,
        payer = authority,
        space = ComplianceLevel::INIT_SPACE
    )]
    pub compliance_level: Account<'info, ComplianceLevel>,
}

impl<'info> SetComplianceLevel<'info> {
    pub fn handler(
        ctx: Context<Self>,
        level: u8,
        name: String,
        description: String,
        requires_kyc: bool,
        requires_aml: bool,
        requires_residency: bool,
        max_transfer_limit: u64,
    ) -> Result<()> {
        let registry = &ctx.accounts.registry;

        // Validate authority
        if registry.authority != ctx.accounts.authority.key() {
            return Err(KycError::InvalidAuthority.into());
        }

        // Validate level
        if level == 0 || level > MAX_COMPLIANCE_LEVELS {
            return Err(KycError::InvalidComplianceLevel.into());
        }

        let compliance_level = &mut ctx.accounts.compliance_level;
        let bump = ctx.bumps.compliance_level;

        compliance_level.level = level;
        compliance_level.name = name;
        compliance_level.description = description;
        compliance_level.requires_kyc = requires_kyc;
        compliance_level.requires_aml = requires_aml;
        compliance_level.requires_residency = requires_residency;
        compliance_level.max_transfer_limit = max_transfer_limit;
        compliance_level.bump = bump;
        compliance_level.reserved = Vec::new();

        msg!("Compliance level {} set: {}", level, compliance_level.name);
        Ok(())
    }
}
