//! Identity management instructions
//!
//! Contains instructions for registering and managing user identities.

use crate::constants::{pda_seeds, COMPLIANCE_HASH_LENGTH, COUNTRY_CODE_LENGTH};
use crate::errors::KycError;
use crate::state::{Identity, IdentityRegistered, IdentityUpdateType, IdentityUpdated};
use anchor_lang::prelude::*;
use anchor_lang::solana_program::system_program;

/// Registers a new identity
///
/// # Arguments
/// * `owner` - The wallet address to register
/// * `compliance_hash` - Hash of the compliance verification data
/// * `expiry` - When the verification expires (Unix timestamp)
/// * `compliance_level` - The compliance tier achieved
/// * `country_code` - ISO 3166-1 alpha-2 country code
#[derive(Accounts)]
#[instruction(
    owner: Pubkey,
    compliance_hash: [u8; COMPLIANCE_HASH_LENGTH],
    expiry: i64,
    compliance_level: u8,
    country_code: [u8; COUNTRY_CODE_LENGTH]
)]
pub struct RegisterIdentity<'info> {
    /// The authority (registry admin or delegate) signing the transaction
    #[account(mut)]
    pub authority: Signer<'info>,

    /// The system program
    #[account(address = system_program::ID)]
    pub system_program: Program<'info, System>,

    /// The registry account
    #[account(
        seeds = [pda_seeds::REGISTRY],
        bump = registry.bump
    )]
    pub registry: Account<'info, Registry>,

    /// The identity account to create (PDA)
    #[account(
        init,
        seeds = [pda_seeds::IDENTITY, &registry.key().to_bytes(), &owner.to_bytes()],
        bump,
        payer = authority,
        space = Identity::INIT_SPACE
    )]
    pub identity: Account<'info, Identity>,
}

impl<'info> RegisterIdentity<'info> {
    pub fn handler(
        ctx: Context<Self>,
        owner: Pubkey,
        compliance_hash: [u8; COMPLIANCE_HASH_LENGTH],
        expiry: i64,
        compliance_level: u8,
        country_code: [u8; COUNTRY_CODE_LENGTH],
    ) -> Result<()> {
        let registry = &ctx.accounts.registry;
        let authority_key = ctx.accounts.authority.key();

        // Validate authority (either registry authority or delegate)
        if registry.authority != authority_key && registry.delegate != Some(authority_key) {
            return Err(KycError::InvalidAuthority.into());
        }

        // Validate compliance level
        if compliance_level == 0 || compliance_level > 10 {
            return Err(KycError::InvalidComplianceLevel.into());
        }

        // Validate expiry
        if expiry <= 0 {
            return Err(KycError::InvalidParameter.into());
        }

        // Check if country is restricted
        if registry.is_country_restricted(&country_code) {
            return Err(KycError::CountryNotAllowed.into());
        }

        let identity = &mut ctx.accounts.identity;
        let bump = ctx.bumps.identity;

        identity.owner = owner;
        identity.registry = registry.key();
        identity.compliance_hash = compliance_hash;
        identity.expiry = expiry;
        identity.compliance_level = compliance_level;
        identity.country_code = country_code;
        identity.is_frozen = false;
        identity.is_revoked = false;
        identity.is_kyc_verified = true;
        identity.is_aml_verified = false;
        identity.bump = bump;
        identity.metadata = Vec::new();
        identity.reserved = Vec::new();

        emit!(IdentityRegistered {
            owner,
            registry: registry.key(),
            compliance_level,
            timestamp: Clock::get()?.unix_timestamp,
        });

        msg!("Identity registered for: {}", owner);
        Ok(())
    }
}

/// Updates an existing identity
#[derive(Accounts)]
#[instruction(
    expiry: Option<i64>,
    compliance_level: Option<u8>,
    country_code: Option<[u8; COUNTRY_CODE_LENGTH]>,
    metadata: Option<Vec<u8>>
)]
pub struct UpdateIdentity<'info> {
    /// The authority (registry admin or delegate) signing the transaction
    #[account(mut)]
    pub authority: Signer<'info>,

    /// The registry account
    #[account(
        seeds = [pda_seeds::REGISTRY],
        bump = registry.bump
    )]
    pub registry: Account<'info, Registry>,

    /// The identity account to update
    #[account(
        mut,
        seeds = [pda_seeds::IDENTITY, &registry.key().to_bytes(), &identity.owner.to_bytes()],
        bump = identity.bump
    )]
    pub identity: Account<'info, Identity>,
}

impl<'info> UpdateIdentity<'info> {
    pub fn handler(
        ctx: Context<Self>,
        expiry: Option<i64>,
        compliance_level: Option<u8>,
        country_code: Option<[u8; COUNTRY_CODE_LENGTH]>,
        metadata: Option<Vec<u8>>,
    ) -> Result<()> {
        let registry = &ctx.accounts.registry;
        let authority_key = ctx.accounts.authority.key();

        // Validate authority
        if registry.authority != authority_key && registry.delegate != Some(authority_key) {
            return Err(KycError::InvalidAuthority.into());
        }

        let identity = &mut ctx.accounts.identity;

        // Update expiry if provided
        if let Some(new_expiry) = expiry {
            if new_expiry <= 0 {
                return Err(KycError::InvalidParameter.into());
            }
            identity.update_expiry(new_expiry);
            emit!(IdentityUpdated {
                owner: identity.owner,
                registry: registry.key(),
                update_type: IdentityUpdateType::ExpiryUpdated,
                timestamp: Clock::get()?.unix_timestamp,
            });
        }

        // Update compliance level if provided
        if let Some(level) = compliance_level {
            if level == 0 || level > 10 {
                return Err(KycError::InvalidComplianceLevel.into());
            }
            identity.update_compliance_level(level);
            emit!(IdentityUpdated {
                owner: identity.owner,
                registry: registry.key(),
                update_type: IdentityUpdateType::ComplianceLevelUpdated,
                timestamp: Clock::get()?.unix_timestamp,
            });
        }

        // Update country code if provided
        if let Some(code) = country_code {
            // Check if new country is restricted
            if registry.is_country_restricted(&code) {
                return Err(KycError::CountryNotAllowed.into());
            }
            identity.country_code = code;
        }

        // Update metadata if provided
        if let Some(meta) = metadata {
            identity.metadata = meta;
        }

        msg!("Identity updated for: {}", identity.owner);
        Ok(())
    }
}

/// Freezes an identity (prevents transfers)
#[derive(Accounts)]
pub struct FreezeIdentity<'info> {
    /// The authority (registry admin or delegate) signing the transaction
    #[account(mut)]
    pub authority: Signer<'info>,

    /// The registry account
    #[account(
        seeds = [pda_seeds::REGISTRY],
        bump = registry.bump
    )]
    pub registry: Account<'info, Registry>,

    /// The identity account to freeze
    #[account(
        mut,
        seeds = [pda_seeds::IDENTITY, &registry.key().to_bytes(), &identity.owner.to_bytes()],
        bump = identity.bump
    )]
    pub identity: Account<'info, Identity>,
}

impl<'info> FreezeIdentity<'info> {
    pub fn handler(ctx: Context<Self>) -> Result<()> {
        let registry = &ctx.accounts.registry;
        let authority_key = ctx.accounts.authority.key();

        // Validate authority
        if registry.authority != authority_key && registry.delegate != Some(authority_key) {
            return Err(KycError::InvalidAuthority.into());
        }

        let identity = &mut ctx.accounts.identity;
        identity.freeze();

        emit!(IdentityUpdated {
            owner: identity.owner,
            registry: registry.key(),
            update_type: IdentityUpdateType::Frozen,
            timestamp: Clock::get()?.unix_timestamp,
        });

        msg!("Identity frozen for: {}", identity.owner);
        Ok(())
    }
}

/// Unfreezes an identity (allows transfers)
#[derive(Accounts)]
pub struct UnfreezeIdentity<'info> {
    /// The authority (registry admin or delegate) signing the transaction
    #[account(mut)]
    pub authority: Signer<'info>,

    /// The registry account
    #[account(
        seeds = [pda_seeds::REGISTRY],
        bump = registry.bump
    )]
    pub registry: Account<'info, Registry>,

    /// The identity account to unfreeze
    #[account(
        mut,
        seeds = [pda_seeds::IDENTITY, &registry.key().to_bytes(), &identity.owner.to_bytes()],
        bump = identity.bump
    )]
    pub identity: Account<'info, Identity>,
}

impl<'info> UnfreezeIdentity<'info> {
    pub fn handler(ctx: Context<Self>) -> Result<()> {
        let registry = &ctx.accounts.registry;
        let authority_key = ctx.accounts.authority.key();

        // Validate authority
        if registry.authority != authority_key && registry.delegate != Some(authority_key) {
            return Err(KycError::InvalidAuthority.into());
        }

        let identity = &mut ctx.accounts.identity;
        identity.unfreeze();

        emit!(IdentityUpdated {
            owner: identity.owner,
            registry: registry.key(),
            update_type: IdentityUpdateType::Unfrozen,
            timestamp: Clock::get()?.unix_timestamp,
        });

        msg!("Identity unfrozen for: {}", identity.owner);
        Ok(())
    }
}

/// Revokes an identity (permanent removal)
#[derive(Accounts)]
pub struct RevokeIdentity<'info> {
    /// The authority (registry admin only, not delegate) signing the transaction
    #[account(mut)]
    pub authority: Signer<'info>,

    /// The registry account
    #[account(
        seeds = [pda_seeds::REGISTRY],
        bump = registry.bump
    )]
    pub registry: Account<'info, Registry>,

    /// The identity account to revoke
    #[account(
        mut,
        seeds = [pda_seeds::IDENTITY, &registry.key().to_bytes(), &identity.owner.to_bytes()],
        bump = identity.bump
    )]
    pub identity: Account<'info, Identity>,
}

impl<'info> RevokeIdentity<'info> {
    pub fn handler(ctx: Context<Self>) -> Result<()> {
        let registry = &ctx.accounts.registry;
        let authority_key = ctx.accounts.authority.key();

        // Only registry authority can revoke (not delegate)
        if registry.authority != authority_key {
            return Err(KycError::InvalidAuthority.into());
        }

        let identity = &mut ctx.accounts.identity;
        identity.revoke();

        emit!(IdentityUpdated {
            owner: identity.owner,
            registry: registry.key(),
            update_type: IdentityUpdateType::Revoked,
            timestamp: Clock::get()?.unix_timestamp,
        });

        msg!("Identity revoked for: {}", identity.owner);
        Ok(())
    }
}

/// Verifies AML for an identity
#[derive(Accounts)]
pub struct VerifyAml<'info> {
    /// The authority (registry admin or delegate) signing the transaction
    #[account(mut)]
    pub authority: Signer<'info>,

    /// The registry account
    #[account(
        seeds = [pda_seeds::REGISTRY],
        bump = registry.bump
    )]
    pub registry: Account<'info, Registry>,

    /// The identity account to verify
    #[account(
        mut,
        seeds = [pda_seeds::IDENTITY, &registry.key().to_bytes(), &identity.owner.to_bytes()],
        bump = identity.bump
    )]
    pub identity: Account<'info, Identity>,
}

impl<'info> VerifyAml<'info> {
    pub fn handler(ctx: Context<Self>) -> Result<()> {
        let registry = &ctx.accounts.registry;
        let authority_key = ctx.accounts.authority.key();

        // Validate authority
        if registry.authority != authority_key && registry.delegate != Some(authority_key) {
            return Err(KycError::InvalidAuthority.into());
        }

        let identity = &mut ctx.accounts.identity;
        identity.verify_aml();

        emit!(IdentityUpdated {
            owner: identity.owner,
            registry: registry.key(),
            update_type: IdentityUpdateType::AmlVerified,
            timestamp: Clock::get()?.unix_timestamp,
        });

        msg!("AML verified for: {}", identity.owner);
        Ok(())
    }
}

/// Closes an identity account
#[derive(Accounts)]
pub struct CloseIdentity<'info> {
    /// The authority (registry admin only) signing the transaction
    #[account(mut)]
    pub authority: Signer<'info>,

    /// The destination for the lamports
    #[account(mut)]
    pub destination: SystemAccount<'info>,

    /// The registry account
    #[account(
        seeds = [pda_seeds::REGISTRY],
        bump = registry.bump
    )]
    pub registry: Account<'info, Registry>,

    /// The identity account to close
    #[account(
        mut,
        close = destination,
        seeds = [pda_seeds::IDENTITY, &registry.key().to_bytes(), &identity.owner.to_bytes()],
        bump = identity.bump
    )]
    pub identity: Account<'info, Identity>,
}

impl<'info> CloseIdentity<'info> {
    pub fn handler(ctx: Context<Self>) -> Result<()> {
        let registry = &ctx.accounts.registry;
        let authority_key = ctx.accounts.authority.key();

        // Only registry authority can close
        if registry.authority != authority_key {
            return Err(KycError::InvalidAuthority.into());
        }

        msg!("Identity closed for: {}", ctx.accounts.identity.owner);
        Ok(())
    }
}
