//! KYC Compliance Program
//!
//! A privacy-preserving compliance framework using Solana Token Extensions (Token-2022) Transfer Hooks.
//! Maintains an on-chain registry of verified identities (hashed/ZK proofs) and intercepts token
//! transfers to enforce allow-list logic.
//!
//! ## Architecture
//!
//! - **Registry**: Global configuration account that holds the compliance authority and settings
//! - **Identity Account**: User-specific account storing their compliance status and verification data
//! - **Transfer Hook**: Intercepts token transfers and validates both source and destination
//!
//! ## Security Considerations
//!
//! - Only the registry authority can register or update identities
//! - All PDA derivations are validated
//! - Transfer validation is atomic - no partial transfers allowed
//! - Privacy is maintained through hash-only storage of compliance data

pub mod constants;
pub mod errors;
pub mod instructions;
pub mod state;

use anchor_lang::prelude::*;

pub use errors::KycError;
pub use instructions::*;
pub use state::*;

/// Program ID of the KYC Compliance program
pub const KYC_COMPLIANCE_PROGRAM_ID: Pubkey = solana_program::pubkey!("KYCCom5KiZAyWvt1m1c9wL8rJ9jB8x7Z3vT4qN2wX6y");

/// Seeds for deriving program-derived addresses
pub mod seeds {
    use super::*;

    /// Seed prefix for the registry account
    pub const REGISTRY: &[u8] = b"registry";

    /// Seed prefix for identity accounts
    pub const IDENTITY: &[u8] = b"identity";

    /// Seed prefix for mint metadata
    pub const MINT_METADATA: &[u8] = b"mint_metadata";

    /// Seed prefix for compliance level
    pub const COMPLIANCE_LEVEL: &[u8] = b"compliance_level";
}

/// Initializes the KYC Compliance program
#[cfg(not(feature = "no-entrypoint"))]
mod entrypoint {
    use super::*;

    #[entrypoint]
    pub fn entrypoint(program_id: &Pubkey, accounts: &[AccountInfo], data: &[u8]) -> ProgramResult {
        processor::process(program_id, accounts, data)
    }
}
