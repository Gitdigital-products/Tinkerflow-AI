//! Instruction processor for the KYC Compliance program
//!
//! Routes incoming instructions to the appropriate handlers.

use crate::instructions::*;
use anchor_lang::prelude::*;
use anchor_lang::solana_program::instruction::Instruction;
use anchor_lang::solana_program::program_error::ProgramError;

/// Processes incoming instructions
pub fn process(program_id: &Pubkey, accounts: &[AccountInfo], data: &[u8]) -> ProgramResult {
    // Decode the instruction
    let instruction = Instruction::unpack(data)?;

    // Route to the appropriate handler
    match instruction {
        // Admin instructions
        Instruction::InitializeRegistry(init) => {
            init.execute(accounts, program_id)
        }
        Instruction::UpdateRegistry(update) => {
            update.execute(accounts, program_id)
        }
        Instruction::SetRegistryPause(pause) => {
            pause.execute(accounts, program_id)
        }
        Instruction::SetDelegate(delegate) => {
            delegate.execute(accounts, program_id)
        }
        Instruction::ConfigureMint(configure) => {
            configure.execute(accounts, program_id)
        }
        Instruction::UpdateMaxTransfer(max_transfer) => {
            max_transfer.execute(accounts, program_id)
        }
        Instruction::SetComplianceLevel(level) => {
            level.execute(accounts, program_id)
        }

        // Identity instructions
        Instruction::RegisterIdentity(register) => {
            register.execute(accounts, program_id)
        }
        Instruction::UpdateIdentity(update) => {
            update.execute(accounts, program_id)
        }
        Instruction::FreezeIdentity(freeze) => {
            freeze.execute(accounts, program_id)
        }
        Instruction::UnfreezeIdentity(unfreeze) => {
            unfreeze.execute(accounts, program_id)
        }
        Instruction::RevokeIdentity(revoke) => {
            revoke.execute(accounts, program_id)
        }
        Instruction::VerifyAml(verify) => {
            verify.execute(accounts, program_id)
        }
        Instruction::CloseIdentity(close) => {
            close.execute(accounts, program_id)
        }

        // Hook instructions
        Instruction::InitializeExtraAccountMeta(init) => {
            init.execute(accounts, program_id)
        }
        Instruction::ExecuteTransferHook(hook) => {
            hook.execute(accounts, program_id)
        }
        Instruction::CpiExecuteTransferHook(cpi_hook) => {
            cpi_hook.execute(accounts, program_id)
        }

        // Unknown instruction
        _ => Err(ProgramError::InvalidInstructionData),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_process_invalid_instruction() {
        // Test that invalid instruction data returns error
        let program_id = Pubkey::default();
        let accounts = &[];
        let data = &[0u8; 0]; // Empty data

        let result = process(&program_id, accounts, data);
        assert!(result.is_err());
    }
}
