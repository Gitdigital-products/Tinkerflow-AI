//! Error definitions for the KYC Compliance program
//!
//! Defines all custom error types that can occur during program execution.

use anchor_lang::prelude::*;

#[derive(Debug, Clone, Copy, PartialEq, Eq, AnchorSerialize, AnchorDeserialize)]
/// Custom error codes for the KYC Compliance program
pub enum KycError {
    // ============== Registry Errors (0-99) ==============
    /// Registry not initialized
    RegistryNotInitialized = 0,
    /// Registry is paused
    RegistryPaused = 1,
    /// Invalid registry authority
    InvalidAuthority = 2,
    /// Registry already initialized
    RegistryAlreadyInitialized = 3,

    // ============== Identity Errors (100-199) ==============
    /// Identity account not found
    IdentityNotFound = 100,
    /// Identity account already exists
    IdentityAlreadyExists = 101,
    /// Identity is expired
    IdentityExpired = 102,
    /// Identity is frozen
    IdentityFrozen = 103,
    /// Identity verification failed
    IdentityVerificationFailed = 104,
    /// Invalid compliance level
    InvalidComplianceLevel = 105,
    /// Compliance level too low
    ComplianceLevelTooLow = 106,

    // ============== Transfer Errors (200-299) ==============
    /// Source identity not found
    SourceIdentityNotFound = 200,
    /// Destination identity not found
    DestinationIdentityNotFound = 201,
    /// Source identity not verified
    SourceNotVerified = 202,
    /// Destination identity not verified
    DestinationNotVerified = 203,
    /// Transfer amount exceeds limit
    TransferAmountExceedsLimit = 204,
    /// Country not allowed
    CountryNotAllowed = 205,
    /// Sanctioned entity detected
    SanctionedEntityDetected = 206,

    // ============== Validation Errors (300-399) ==============
    /// Invalid PDA derivation
    InvalidPdaDerivation = 300,
    /// Invalid account data
    InvalidAccountData = 301,
    /// Invalid signature
    InvalidSignature = 302,
    /// Account not writable
    AccountNotWritable = 303,
    /// Mint not supported
    MintNotSupported = 304,

    // ============== Hook Errors (400-499) ==============
    /// Transfer hook execution failed
    HookExecutionFailed = 400,
    /// Invalid hook account
    InvalidHookAccount = 401,
    /// Extra account meta not found
    ExtraAccountMetaNotFound = 402,

    // ============== General Errors (500-599) ==============
    /// Math overflow
    MathOverflow = 500,
    /// Invalid parameter
    InvalidParameter = 501,
    /// Unauthorized
    Unauthorized = 502,
    /// Internal error
    InternalError = 503,
}

impl From<KycError> for ProgramError {
    fn from(e: KycError) -> Self {
        ProgramError::Custom(e as u32)
    }
}

impl std::fmt::Display for KycError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            // Registry Errors
            KycError::RegistryNotInitialized => write!(f, "Registry not initialized"),
            KycError::RegistryPaused => write!(f, "Registry is paused"),
            KycError::InvalidAuthority => write!(f, "Invalid registry authority"),
            KycError::RegistryAlreadyInitialized => write!(f, "Registry already initialized"),

            // Identity Errors
            KycError::IdentityNotFound => write!(f, "Identity account not found"),
            KycError::IdentityAlreadyExists => write!(f, "Identity account already exists"),
            KycError::IdentityExpired => write!(f, "Identity has expired"),
            KycError::IdentityFrozen => write!(f, "Identity is frozen"),
            KycError::IdentityVerificationFailed => write!(f, "Identity verification failed"),
            KycError::InvalidComplianceLevel => write!(f, "Invalid compliance level"),
            KycError::ComplianceLevelTooLow => write!(f, "Compliance level too low"),

            // Transfer Errors
            KycError::SourceIdentityNotFound => write!(f, "Source identity not found"),
            KycError::DestinationIdentityNotFound => write!(f, "Destination identity not found"),
            KycError::SourceNotVerified => write!(f, "Source identity not verified"),
            KycError::DestinationNotVerified => write!(f, "Destination identity not verified"),
            KycError::TransferAmountExceedsLimit => write!(f, "Transfer amount exceeds limit"),
            KycError::CountryNotAllowed => write!(f, "Country not allowed"),
            KycError::SanctionedEntityDetected => write!(f, "Sanctioned entity detected"),

            // Validation Errors
            KycError::InvalidPdaDerivation => write!(f, "Invalid PDA derivation"),
            KycError::InvalidAccountData => write!(f, "Invalid account data"),
            KycError::InvalidSignature => write!(f, "Invalid signature"),
            KycError::AccountNotWritable => write!(f, "Account not writable"),
            KycError::MintNotSupported => write!(f, "Mint not supported"),

            // Hook Errors
            KycError::HookExecutionFailed => write!(f, "Transfer hook execution failed"),
            KycError::InvalidHookAccount => write!(f, "Invalid hook account"),
            KycError::ExtraAccountMetaNotFound => write!(f, "Extra account meta not found"),

            // General Errors
            KycError::MathOverflow => write!(f, "Math overflow"),
            KycError::InvalidParameter => write!(f, "Invalid parameter"),
            KycError::Unauthorized => write!(f, "Unauthorized"),
            KycError::InternalError => write!(f, "Internal error"),
        }
    }
}

impl std::error::Error for KycError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        None
    }
}
